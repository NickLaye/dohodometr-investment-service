# Pydantic схемы
