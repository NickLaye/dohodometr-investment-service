"""
Сервис учета инвестиций - Backend API

Облачный сервис для учёта инвестиционных портфелей русскоязычных пользователей.
"""

__version__ = "1.0.0"
__description__ = "Investment Portfolio Tracking Service"
__author__ = "Investment Service Team"
